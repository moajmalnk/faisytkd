# NKBook Database Setup Guide

This guide explains how to set up the database for both local development and production environments.

## 🏠 Local Development Setup

### Prerequisites
- MySQL/MariaDB server running locally
- PHP with PDO MySQL extension
- Web server (Apache/Nginx) or PHP built-in server

### Quick Setup

1. **Run the setup script:**
   ```bash
   cd backend
   php setup-db.php
   ```

2. **Or manual setup:**
   ```bash
   # Create database
   mysql -u root -p -e "CREATE DATABASE nkbook CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
   
   # Import schema
   mysql -u root -p nkbook < schema.sql
   ```

3. **Configure environment:**
   - Copy `.env.example` to `.env.local`
   - Update database credentials if needed

### Local Database Configuration
```env
APP_ENV=development
DB_HOST=localhost
DB_PORT=3306
DB_NAME=nkbook
DB_USER=root
DB_PASS=
```

## 🌐 Production Setup

### Environment Variables

Create a `.env` file in the backend directory with production settings:

```env
# Production Environment
APP_ENV=production
APP_DEBUG=false

# Production Database Configuration
DB_HOST=your-production-host
DB_PORT=3306
DB_NAME=your-production-db
DB_USER=your-production-user
DB_PASS=your-secure-password
DB_CHARSET=utf8mb4

# API Configuration
API_BASE_URL=https://your-domain.com/api
FRONTEND_URL=https://your-domain.com

# Security (generate strong secrets)
JWT_SECRET=your-super-secure-jwt-secret-key
API_RATE_LIMIT=100

# Logging
LOG_LEVEL=error
LOG_FILE=logs/app.log
```

### Production Database Setup

1. **Create production database:**
   ```sql
   CREATE DATABASE your_production_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   CREATE USER 'your_user'@'%' IDENTIFIED BY 'your_secure_password';
   GRANT ALL PRIVILEGES ON your_production_db.* TO 'your_user'@'%';
   FLUSH PRIVILEGES;
   ```

2. **Import schema:**
   ```bash
   mysql -u your_user -p your_production_db < schema.sql
   ```

3. **Test connection:**
   ```bash
   php -r "require_once 'database.php'; new Database(); echo 'Connection successful!';"
   ```

## 🔧 Configuration Details

### Database Connection Options

The system automatically detects the environment and uses appropriate settings:

- **Development**: Uses `.env.local` or defaults to local MySQL
- **Production**: Uses `.env` or environment variables

### Supported Environment Variables

| Variable | Description | Default (Dev) | Default (Prod) |
|----------|-------------|---------------|----------------|
| `APP_ENV` | Environment mode | development | production |
| `APP_DEBUG` | Debug mode | true | false |
| `DB_HOST` | Database host | localhost | localhost |
| `DB_PORT` | Database port | 3306 | 3306 |
| `DB_NAME` | Database name | nkbook | u524154866_kanakk |
| `DB_USER` | Database user | root | u524154866_kanakk |
| `DB_PASS` | Database password | (empty) | CodoMail@8848 |
| `DB_CHARSET` | Character set | utf8mb4 | utf8mb4 |

### Security Best Practices

1. **Never commit sensitive files:**
   - Add `.env`, `.env.local`, `.env.production` to `.gitignore`
   - Only commit `.env.example`

2. **Use strong passwords:**
   - Generate secure passwords for production
   - Use different credentials for each environment

3. **Restrict database access:**
   - Use specific user accounts (not root) for production
   - Limit host access in MySQL user grants

4. **Enable SSL:**
   - Configure MySQL SSL for production
   - Use secure connections in production

## 🧪 Testing

### Test Database Connection
```bash
# Test local connection
php -r "require_once 'backend/database.php'; new Database(); echo 'Local connection OK!';"

# Test with specific environment
APP_ENV=production php -r "require_once 'backend/database.php'; new Database(); echo 'Production connection OK!';"
```

### Test API Endpoints
```bash
# Health check
curl http://localhost/backend/health.php

# Test accounts endpoint
curl http://localhost/backend/accounts.php
```

## 🚨 Troubleshooting

### Common Issues

1. **Connection refused:**
   - Check if MySQL server is running
   - Verify host and port settings
   - Check firewall settings

2. **Access denied:**
   - Verify username and password
   - Check MySQL user permissions
   - Ensure user can connect from your host

3. **Database not found:**
   - Create the database manually
   - Run the setup script
   - Check database name spelling

4. **Character set issues:**
   - Ensure database uses utf8mb4
   - Check table collation settings
   - Verify PHP charset configuration

### Debug Mode

Enable debug mode for detailed error messages:
```env
APP_ENV=development
APP_DEBUG=true
```

## 📁 File Structure

```
backend/
├── .env.example          # Environment template
├── .env.local           # Local development config (not committed)
├── .env                 # Production config (not committed)
├── config.php           # Main configuration file
├── database.php         # Database connection class
├── setup-db.php         # Database setup script
├── schema.sql           # Database schema
└── README-DATABASE.md   # This file
```

## 🔄 Migration Between Environments

### Local to Production
1. Export local data: `mysqldump -u root nkbook > backup.sql`
2. Update production `.env` file
3. Import to production: `mysql -u user -p prod_db < backup.sql`

### Production to Local
1. Export production data
2. Create local database
3. Import data to local database
4. Update local `.env.local` file
