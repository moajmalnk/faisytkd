<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/utils.php';

cors();

$db = new Database();
$pdo = $db->pdo();

try {
  switch (method()) {
    case 'GET':
      $stmt = $pdo->query('SELECT id, name, type, color, created_at FROM categories ORDER BY id DESC');
      send_json(['ok' => true, 'items' => $stmt->fetchAll()]);
    case 'POST':
      $body = read_json_body();
      $stmt = $pdo->prepare('INSERT INTO categories (name, type, color) VALUES (?, ?, ?)');
      $stmt->execute([
        $body['name'] ?? 'New Category',
        $body['type'] ?? 'expense',
        $body['color'] ?? '#3b82f6',
      ]);
      send_json(['ok' => true, 'id' => $pdo->lastInsertId()]);
    case 'PUT':
    case 'PATCH':
      $id = $_GET['id'] ?? null;
      if (!$id) send_json(['ok' => false, 'error' => 'Missing id'], 400);
      $body = read_json_body();
      $stmt = $pdo->prepare('UPDATE categories SET name = ?, type = ?, color = ? WHERE id = ?');
      $stmt->execute([
        $body['name'] ?? 'New Category',
        $body['type'] ?? 'expense',
        $body['color'] ?? '#3b82f6',
        $id,
      ]);
      send_json(['ok' => true]);
    case 'DELETE':
      $id = $_GET['id'] ?? null;
      if (!$id) send_json(['ok' => false, 'error' => 'Missing id'], 400);
      $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
      $stmt->execute([$id]);
      send_json(['ok' => true]);
    default:
      send_json(['ok' => false, 'error' => 'Method not allowed'], 405);
  }
} catch (Throwable $e) {
  send_json(['ok' => false, 'error' => $e->getMessage()], 500);
}

?>


