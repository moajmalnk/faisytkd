<?php
// Basic configuration for database connection

// IMPORTANT: These credentials come from the user. Consider moving them to environment
// variables in production and never commit secrets to public repositories.

define('DB_HOST', 'localhost');
define('DB_NAME', 'u524154866_kanakk');
define('DB_USER', 'u524154866_kanakk');
define('DB_PASS', 'CodoMail@8848');
define('DB_CHARSET', 'utf8mb4');

// Allowed origins for CORS (adjust to your frontend URL as needed)
$allowedOrigins = [
  '*',
];

function send_json($data, $status = 200) {
  http_response_code($status);
  header('Content-Type: application/json');
  echo json_encode($data);
  exit;
}

function cors() {
  global $allowedOrigins;
  $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
  if (in_array('*', $allowedOrigins) || in_array($origin, $allowedOrigins)) {
    header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
  }
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
  }
}

?>


