<?php
// Professional database configuration for local and production environments

// Load environment variables from .env file if it exists
function loadEnv($path) {
  if (!file_exists($path)) {
    return false;
  }
  
  $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  foreach ($lines as $line) {
    if (strpos(trim($line), '#') === 0) {
      continue;
    }
    
    list($name, $value) = explode('=', $line, 2);
    $_ENV[trim($name)] = trim($value);
  }
  return true;
}

// Try to load .env file from different locations
$envLoaded = false;
$envPaths = [
  __DIR__ . '/.env',
  __DIR__ . '/.env.local',
  dirname(__DIR__) . '/.env',
];

foreach ($envPaths as $path) {
  if (loadEnv($path)) {
    $envLoaded = true;
    break;
  }
}

// Environment detection
$isProduction = isset($_ENV['APP_ENV']) && $_ENV['APP_ENV'] === 'production';

// Database configuration with environment variables
define('DB_HOST', $_ENV['DB_HOST'] ?? ($isProduction ? 'localhost' : 'localhost'));
define('DB_NAME', $_ENV['DB_NAME'] ?? ($isProduction ? 'u524154866_kanakk' : 'nkbook'));
define('DB_USER', $_ENV['DB_USER'] ?? ($isProduction ? 'u524154866_kanakk' : 'root'));
define('DB_PASS', $_ENV['DB_PASS'] ?? ($isProduction ? 'CodoMail@8848' : ''));
define('DB_CHARSET', $_ENV['DB_CHARSET'] ?? 'utf8mb4');
define('DB_PORT', $_ENV['DB_PORT'] ?? '3306');

// Application configuration
define('APP_ENV', $_ENV['APP_ENV'] ?? 'development');
define('APP_DEBUG', $_ENV['APP_DEBUG'] ?? 'true');

// Allowed origins for CORS (adjust to your frontend URL as needed)
$allowedOrigins = [
  '*',
];

function send_json($data, $status = 200) {
  http_response_code($status);
  header('Content-Type: application/json');
  echo json_encode($data);
  exit;
}

function cors() {
  global $allowedOrigins;
  $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
  if (in_array('*', $allowedOrigins) || in_array($origin, $allowedOrigins)) {
    header('Access-Control-Allow-Origin: ' . ($origin ?: '*'));
  }
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
  }
}

?>


