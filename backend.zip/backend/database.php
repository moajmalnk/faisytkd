<?php
require_once __DIR__ . '/config.php';

class Database {
  private $pdo;

  public function __construct() {
    // Use SQLite for development if MySQL connection fails
    if (APP_ENV === 'development') {
      $dbFile = __DIR__ . '/nkbook.db';
      $dsn = 'sqlite:' . $dbFile;
      $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ];
    } else {
      $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
      $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET,
      ];
    }
    
    try {
      if (APP_ENV === 'development') {
        $this->pdo = new PDO($dsn, null, null, $options);
      } else {
        $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
      }
      
      // Log successful connection in development
      if (APP_ENV === 'development' && APP_DEBUG === 'true') {
        error_log("Database connected successfully to: " . DB_HOST . ":" . DB_PORT . "/" . DB_NAME);
      }
    } catch (PDOException $e) {
      $errorMsg = APP_ENV === 'production' 
        ? 'Database connection failed' 
        : 'DB connection failed: ' . $e->getMessage();
      
      error_log("Database connection error: " . $e->getMessage());
      send_json(['ok' => false, 'error' => $errorMsg, 'details' => $e->getMessage()], 500);
    }
  }

  public function pdo() {
    return $this->pdo;
  }
}

?>


