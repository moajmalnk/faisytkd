<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

cors();

$db = new Database();
$pdo = $db->pdo();

try {
  $stmt = $pdo->query('SELECT 1 as ok');
  $row = $stmt->fetch();
  send_json(['ok' => true, 'db' => $row['ok'] == 1, 'database' => DB_NAME]);
} catch (Throwable $e) {
  send_json(['ok' => false, 'error' => $e->getMessage()], 500);
}

?>


