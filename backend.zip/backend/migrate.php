<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

// Apply database schema migrations
try {
  $db = new Database();
  $pdo = $db->pdo();
  
  echo "Starting database migration...\n";
  
  // Add completed column to transactions table if it doesn't exist
  $stmt = $pdo->query("SHOW COLUMNS FROM transactions LIKE 'completed'");
  if ($stmt->rowCount() == 0) {
    echo "Adding completed column to transactions table...\n";
    $pdo->exec("ALTER TABLE transactions ADD COLUMN completed BOOLEAN DEFAULT FALSE");
    echo "✓ Added completed column\n";
  } else {
    echo "✓ Completed column already exists\n";
  }
  
  // Add index for completed column
  try {
    $pdo->exec("ALTER TABLE transactions ADD INDEX idx_transactions_completed (completed)");
    echo "✓ Added index for completed column\n";
  } catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
      echo "✓ Index for completed column already exists\n";
    } else {
      throw $e;
    }
  }
  
  echo "Migration completed successfully!\n";
  
} catch (Exception $e) {
  echo "Migration failed: " . $e->getMessage() . "\n";
  exit(1);
}
?>
