-- Starter schema for nkbook bookkeeping

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('income','expense') NOT NULL,
  color VARCHAR(32) DEFAULT '#3b82f6',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_categories_type (type),
  INDEX idx_categories_name (name)
);

CREATE TABLE IF NOT EXISTS accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('cash','bank','credit') NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_accounts_type (type),
  INDEX idx_accounts_name (name),
  INDEX idx_accounts_amount (amount)
);

CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('collect','pay','income','expense') NOT NULL,
  category_id INT NULL,
  account_id INT NULL,
  amount DECIMAL(12,2) NOT NULL,
  note VARCHAR(255),
  occurred_on DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (category_id),
  INDEX (account_id),
  INDEX idx_transactions_occurred_on (occurred_on),
  INDEX idx_transactions_kind (kind),
  INDEX idx_transactions_kind_date (kind, occurred_on),
  INDEX idx_transactions_account_date (account_id, occurred_on),
  INDEX idx_transactions_category_date (category_id, occurred_on),
  CONSTRAINT fk_transactions_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  CONSTRAINT fk_transactions_account FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
);


-- Optional: apply indexes to existing tables if they were created earlier
-- (MySQL 8.0.13+ supports IF NOT EXISTS)
ALTER TABLE categories ADD INDEX IF NOT EXISTS idx_categories_type (type);
ALTER TABLE categories ADD INDEX IF NOT EXISTS idx_categories_name (name);

ALTER TABLE accounts ADD INDEX IF NOT EXISTS idx_accounts_type (type);
ALTER TABLE accounts ADD INDEX IF NOT EXISTS idx_accounts_name (name);
ALTER TABLE accounts ADD INDEX IF NOT EXISTS idx_accounts_amount (amount);

ALTER TABLE transactions ADD INDEX IF NOT EXISTS idx_transactions_occurred_on (occurred_on);
ALTER TABLE transactions ADD INDEX IF NOT EXISTS idx_transactions_kind (kind);
ALTER TABLE transactions ADD INDEX IF NOT EXISTS idx_transactions_kind_date (kind, occurred_on);
ALTER TABLE transactions ADD INDEX IF NOT EXISTS idx_transactions_account_date (account_id, occurred_on);
ALTER TABLE transactions ADD INDEX IF NOT EXISTS idx_transactions_category_date (category_id, occurred_on);


