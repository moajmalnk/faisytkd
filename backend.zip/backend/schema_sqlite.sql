-- SQLite schema for nkbook bookkeeping

CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name VARCHAR(100) NOT NULL,
  type TEXT CHECK(type IN ('income','expense')) NOT NULL,
  color VARCHAR(32) DEFAULT '#3b82f6',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_categories_type ON categories (type);
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories (name);

CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name VARCHAR(100) NOT NULL,
  type TEXT CHECK(type IN ('cash','bank','credit')) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts (type);
CREATE INDEX IF NOT EXISTS idx_accounts_name ON accounts (name);
CREATE INDEX IF NOT EXISTS idx_accounts_amount ON accounts (amount);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT CHECK(kind IN ('collect','pay','income','expense')) NOT NULL,
  category_id INTEGER NULL,
  account_id INTEGER NULL,
  amount DECIMAL(12,2) NOT NULL,
  note VARCHAR(255),
  occurred_on DATE NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_transactions_occurred_on ON transactions (occurred_on);
CREATE INDEX IF NOT EXISTS idx_transactions_kind ON transactions (kind);
CREATE INDEX IF NOT EXISTS idx_transactions_kind_date ON transactions (kind, occurred_on);
CREATE INDEX IF NOT EXISTS idx_transactions_account_date ON transactions (account_id, occurred_on);
CREATE INDEX IF NOT EXISTS idx_transactions_category_date ON transactions (category_id, occurred_on);
CREATE INDEX IF NOT EXISTS idx_transactions_completed ON transactions (completed);
