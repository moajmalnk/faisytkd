<?php
/**
 * Database Setup Script
 * This script helps you set up the database for both local and production environments
 */

require_once __DIR__ . '/config.php';

function createDatabase($host, $port, $user, $pass, $dbname) {
    try {
        // Connect to MySQL server without specifying database
        $dsn = "mysql:host=$host;port=$port;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        
        // Create database if it doesn't exist
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        echo "✅ Database '$dbname' created successfully!\n";
        
        // Connect to the created database
        $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        
        // Read and execute schema
        $schema = file_get_contents(__DIR__ . '/schema.sql');
        if ($schema) {
            $pdo->exec($schema);
            echo "✅ Database schema created successfully!\n";
        } else {
            echo "⚠️  Schema file not found. Please ensure schema.sql exists.\n";
        }
        
        return true;
    } catch (PDOException $e) {
        echo "❌ Database setup failed: " . $e->getMessage() . "\n";
        return false;
    }
}

function setupEnvironmentFiles() {
    $envLocal = <<<'EOF'
# Local Development Environment Configuration
# This file is for local development only

# Application Environment
APP_ENV=development
APP_DEBUG=true

# Database Configuration for Local Development
DB_HOST=localhost
DB_PORT=3306
DB_NAME=nkbook
DB_USER=root
DB_PASS=
DB_CHARSET=utf8mb4

# API Configuration
API_BASE_URL=http://localhost:3000
FRONTEND_URL=http://localhost:5173

# Security (for development only)
JWT_SECRET=your-local-jwt-secret-key-change-this-in-production
API_RATE_LIMIT=1000

# Logging
LOG_LEVEL=debug
LOG_FILE=logs/app.log
EOF;

    $envExample = <<<'EOF'
# Environment Configuration Example
# Copy this file to .env.local for local development or .env for production
# DO NOT commit actual .env files to version control

# Application Environment (development/production)
APP_ENV=development
APP_DEBUG=true

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_NAME=nkbook
DB_USER=root
DB_PASS=
DB_CHARSET=utf8mb4

# API Configuration
API_BASE_URL=http://localhost:3000
FRONTEND_URL=http://localhost:5173

# Security (generate strong secrets for production)
JWT_SECRET=your-jwt-secret-key-change-this-in-production
API_RATE_LIMIT=1000

# Logging
LOG_LEVEL=debug
LOG_FILE=logs/app.log
EOF;

    // Create .env.local for local development
    if (!file_exists(__DIR__ . '/.env.local')) {
        file_put_contents(__DIR__ . '/.env.local', $envLocal);
        echo "✅ Created .env.local for local development\n";
    } else {
        echo "⚠️  .env.local already exists, skipping creation\n";
    }

    // Create .env.example
    if (!file_exists(__DIR__ . '/.env.example')) {
        file_put_contents(__DIR__ . '/.env.example', $envExample);
        echo "✅ Created .env.example template\n";
    } else {
        echo "⚠️  .env.example already exists, skipping creation\n";
    }
}

function testConnection() {
    try {
        require_once __DIR__ . '/database.php';
        $db = new Database();
        echo "✅ Database connection test successful!\n";
        return true;
    } catch (Exception $e) {
        echo "❌ Database connection test failed: " . $e->getMessage() . "\n";
        return false;
    }
}

// Main setup process
echo "🚀 Starting NKBook Database Setup...\n\n";

// Setup environment files
echo "📝 Setting up environment files...\n";
setupEnvironmentFiles();
echo "\n";

// Setup local database
echo "🗄️  Setting up local database...\n";
$success = createDatabase('localhost', '3306', 'root', '', 'nkbook');

if ($success) {
    echo "\n🧪 Testing database connection...\n";
    testConnection();
    
    echo "\n🎉 Setup completed successfully!\n";
    echo "\nNext steps:\n";
    echo "1. Make sure your MySQL server is running\n";
    echo "2. Update .env.local if your database credentials are different\n";
    echo "3. Test your API endpoints\n";
} else {
    echo "\n❌ Setup failed. Please check your database configuration.\n";
}
?>
