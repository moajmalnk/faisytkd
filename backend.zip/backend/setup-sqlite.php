<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

// Setup SQLite database for development
try {
  $db = new Database();
  $pdo = $db->pdo();
  
  echo "Setting up SQLite database...\n";
  
  // Read and execute schema
  $schema = file_get_contents(__DIR__ . '/schema_sqlite.sql');
  $statements = array_filter(array_map('trim', explode(';', $schema)));
  
  foreach ($statements as $statement) {
    if (!empty($statement)) {
      $pdo->exec($statement);
      echo "✓ Executed: " . substr($statement, 0, 50) . "...\n";
    }
  }
  
  // Insert some sample data
  echo "\nInserting sample data...\n";
  
  // Sample categories
  $pdo->exec("INSERT OR IGNORE INTO categories (id, name, type, color) VALUES 
    (1, 'Freelance', 'income', 'hsl(142 76% 36%)'),
    (2, 'Investment', 'income', 'hsl(142 76% 36%)'),
    (3, 'Salary', 'income', 'hsl(142 76% 36%)'),
    (4, 'Food & Dining', 'expense', 'hsl(0 84% 60%)'),
    (5, 'Transportation', 'expense', 'hsl(0 84% 60%)'),
    (6, 'Utilities', 'expense', 'hsl(0 84% 60%)'),
    (7, 'Entertainment', 'expense', 'hsl(0 84% 60%)')");
  
  // Sample accounts
  $pdo->exec("INSERT OR IGNORE INTO accounts (id, name, type, amount) VALUES 
    (1, 'Cash', 'cash', 15740.00),
    (2, 'Kotak Bank', 'bank', 94337.83),
    (3, 'Federal Bank', 'bank', 60791.00),
    (4, 'Credit Card', 'credit', 24836.04)");
  
  // Sample transactions
  $pdo->exec("INSERT OR IGNORE INTO transactions (id, kind, category_id, account_id, amount, note, occurred_on, completed) VALUES 
    (1, 'collect', NULL, NULL, 10000, 'Bro', '2024-01-15', 0),
    (2, 'collect', NULL, NULL, 3800, 'Ashif', '2024-01-16', 0),
    (3, 'pay', NULL, NULL, 40000, 'Uppappa', '2024-01-17', 0),
    (4, 'income', 1, 2, 12000, 'Freelance Project', '2024-01-15', 0),
    (5, 'expense', 4, 1, 2500, 'Groceries', '2024-01-18', 0)");
  
  echo "✓ Sample data inserted\n";
  echo "\nSQLite database setup completed successfully!\n";
  echo "Database file: " . __DIR__ . "/nkbook.db\n";
  
} catch (Exception $e) {
  echo "Setup failed: " . $e->getMessage() . "\n";
  exit(1);
}
?>
