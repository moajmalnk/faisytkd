<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/utils.php';

cors();

$db = new Database();
$pdo = $db->pdo();

try {
  switch (method()) {
    case 'GET':
      $stmt = $pdo->query('SELECT id, kind, category_id, account_id, amount, note, occurred_on, completed, created_at FROM transactions ORDER BY occurred_on DESC, id DESC');
      send_json(['ok' => true, 'items' => $stmt->fetchAll()]);
    case 'POST':
      $b = read_json_body();
      $stmt = $pdo->prepare('INSERT INTO transactions (kind, category_id, account_id, amount, note, occurred_on, completed) VALUES (?, ?, ?, ?, ?, ?, ?)');
      $stmt->execute([
        $b['kind'] ?? 'expense',
        $b['category_id'] ?? null,
        $b['account_id'] ?? null,
        $b['amount'] ?? 0,
        $b['note'] ?? null,
        $b['occurred_on'] ?? date('Y-m-d'),
        $b['completed'] ?? false,
      ]);
      send_json(['ok' => true, 'id' => $pdo->lastInsertId()]);
    case 'PUT':
    case 'PATCH':
      $id = $_GET['id'] ?? null;
      if (!$id) send_json(['ok' => false, 'error' => 'Missing id'], 400);
      $b = read_json_body();
      $stmt = $pdo->prepare('UPDATE transactions SET kind = ?, category_id = ?, account_id = ?, amount = ?, note = ?, occurred_on = ?, completed = ? WHERE id = ?');
      $stmt->execute([
        $b['kind'] ?? 'expense',
        $b['category_id'] ?? null,
        $b['account_id'] ?? null,
        $b['amount'] ?? 0,
        $b['note'] ?? null,
        $b['occurred_on'] ?? date('Y-m-d'),
        $b['completed'] ?? false,
        $id,
      ]);
      send_json(['ok' => true]);
    case 'DELETE':
      $id = $_GET['id'] ?? null;
      if (!$id) send_json(['ok' => false, 'error' => 'Missing id'], 400);
      $stmt = $pdo->prepare('DELETE FROM transactions WHERE id = ?');
      $stmt->execute([$id]);
      send_json(['ok' => true]);
    default:
      send_json(['ok' => false, 'error' => 'Method not allowed'], 405);
  }
} catch (Throwable $e) {
  send_json(['ok' => false, 'error' => $e->getMessage()], 500);
}

?>


