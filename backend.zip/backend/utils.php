<?php
require_once __DIR__ . '/config.php';

function read_json_body() {
  $raw = file_get_contents('php://input');
  if (!$raw) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function method() {
  return $_POST['_method'] ?? $_SERVER['REQUEST_METHOD'];
}

?>


